package com.byt.eemblue.act;

import com.byt.eemblue.R;
import com.byt.eemblue.base.BaseAct;

//关于系统
public class ActAboutUs extends BaseAct {
    @Override
    protected int setupViewRes() {
        return R.layout.act_about_system;
    }

    @Override
    protected void initMain() {

    }
}
